//-------------------------------------------------------------------------------------------------------------------------------------------------
//comparePdb5.cpp
//
//Executes a 1:MM comparison between the chain structures of OO "Fobject" proteins with MM "model" proteins by applying the General Hough
//Transform. Version "3" uses Range Trees for orthogonal listLink searches. Version "4" keeps those trees balanced with appropriate rotations.
//Version 5 onwards have the full set of handles active.
//
//Author: Elio MATTIA
//Date: September 2010
//
//Required files: "global.info" "##.Fprotein" "Fobject.Fprotein" 
//-------------------------------------------------------------------------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

//============================================================== :: TYPEDEF STRUCT :: =============================================================
typedef struct vector {
    float x;
    float y;
    float z;
} vector;

typedef struct chain {
    char type[20];
    int len;
    vector pos;
    vector dir;
    float rho;
    float theta;
} chain;

struct listLink {
    struct voteCube *cube;
    struct listLink *next;
};

struct voteCube {
    vector pos;                       //Voted pos, in the space of the model Fprotein (INV mode) or of the Fobject Fprotein (DIR mode). Positions are in �ngstr�m
                                      //and only those allowed on a spacemesh and refer to the cube having the extreme vertexes of the cube diagonal
                                      //the coordinate here and the next one (with all the values increased by "spacemesh")
    float pointvote;                  //Vote for this pos, depending from rho and theta and the corresponding lengths
                                      //(gaussian around the len of the chain structure of the Fobject Fprotein)
                                      //and types (1 if same, 0.25 if different)
    float smoothedvote;               //Smoothed vote for the given pos, obtained by summing all the votes within radius "sumdist"
    int mm;                            //Number of the voting model Fprotein
    struct listLink *neighbors;
    struct listLink *lastneighbor;
};

typedef struct listLink listLink;
typedef struct voteCube voteCube;

typedef struct treeLink {
    struct treeLink *ltree;
    struct treeLink *rtree;
    float key;
    struct treeLink *utree;
    int isleaf;
    struct listLink *cubes;
    struct listLink *lastcube;
    int bal;
} treeLink;

typedef struct stackLink {
    struct stackLink *inner;
    treeLink **treevertex;
    int delta;
} stackLink;

//============================================================ :: GLOBAL CONSTANTS :: =============================================================
const float pi=3.14159265;

      float spacemesh=0.1;            //Mesh for the voting space (in �ngstr�m), values overridden in adaptivemode mode
      int   meshreg=1;                //Integer regulator for the discretization (1 if spacemesh is multiple of 10, 2 if multiple of 5, 5 if multiple of 2),
                                      //values overridden in adaptivemode mode
      int   phimesh=10;                //Mesh for the voting procedure with respect to phi (number of divisions), values overridden in adaptivemode mode
const float tol=0.1;                  //Tolerance on the smoothing radius and on the exclusion distance
const int   mulsum=1;                 //Multiplier for sumdist and bestdist
const int   muldist=1;
const float sumdist=2*2*sqrt(3)+tol*spacemesh;    //Radius of the smoothing sphere
const int   spherediam=7;             //Diameter of the smoothing sphere (in max number of included points predicted)
const int   permodel=4;               //Number of best votes to write into the "best.list" for each Fprotein
const float bestdist=2*sumdist-2*tol*spacemesh;
                                      //Distance between the centers of the smoothing spheres for mutual exclusion from the "best.list"
const int   R=3;                      //Setter for weight of smoothing with respect to the size of the model (or Fobject [see code]) Fprotein:
                                      //linear (L0), square root (Q1), ramp (R2), uniform (N3), inverse (I4)
const float singlevote=10;            //One vote
const float typewt=0.25;              //Weight for different chain type (alpha or beta) (std=0.25)
const float lenwt=0.2;                //Weight of the exponential for the chain lengths (std=0.2)

const int   skipself=0;               //Setter to avoid (=1) comparing an Fobject Fprotein with itself
      int   invmode=1;                //0 = DIR mode, 1 = INV mode, it is automatically setted to 1 if motifmode is on
const int   perobject=50;             //Number of model proteins to include in the cubes (in INV mode, it can be extended to DIR mode)
                                      //of the model proteins that most probably contain the Fobject Fprotein (INV mode)
const int   motifmode=0;                  //0 = normal mode, 1 = MOTIF mode (INV mode is set to 1 in MOTIF mode)
const int   adaptivemode=0;               //0 = normal mode, 1 = ADAPTIVE mode: "spacemesh" "meshreg" and "phimesh" are automatically tuned for each
                                      //Fobject Fprotein depending on the number of chain structures in the latter (see "main()")

//Debug constants
const int debug1=1;
const int debug2=0;
const int debug3=1;
const int debug4=0;
const int debug5=0;
const int debug6=0;  //Activates {while (true);} in the end
const int debug7=1;  //Prints Favg's

//============================================================ :: GLOBAL VARIABLES :: ============================================================
int OO;              //Number of Fobject proteins
int MM;              //Number of model proteins
int O;               //Number of chains in the Fobject Fprotein
int *M;              //Number of chains in the model Fprotein
char **mms;          //String vector with the model proteins' filenames
char oos[12];        //String vector with the Fobject Fprotein's filename
int sparse;
FILE *Freport;
FILE *Freportplus;
FILE *Fcoverage;       //Coverage of voting on phi
double davg;
float  favg;
FILE *Favg;
char adaptivelabel[30];
//============================================ :: structures and structured lists :: ============================================
chain *objectprotein;                     //Object Fprotein is number oo and has O elements [0..O-1]
//each of the following structured lists declares also the integer keeping track of its size
listLink *cubes;    int dim1;       //Vote cubes for one Fprotein
listLink *lastcube;
treeLink *rangetree;
voteCube **best;                int dim3;       //Smoothed cubes for the model proteins, containing permodel best votes for each
voteCube **bestsort;            int dim4;       //Best cubes sorted by smoothed vote
voteCube **diffptrs;         float *difference;  //Differences (between the two best peaks for each model Fprotein) cubes with pointers to "bestsort" cubes and actual diffptrs in a vector
//================================================================ :: PROTOTYPES :: ================================================================

void freeEverything();

float dot(vector, vector);
void cross(vector, vector, vector *);
void normalize(vector *);
int compare(vector, vector);
float distance(vector, vector);


void makeVotePosition(vector, vector *);
void rototranslate(vector, vector *, vector, vector *);

void makeCount();
void readData();
void readParameters();
void allocateStructures();
void vote(int,chain *,int);
int lookfor(treeLink **,float,treeLink **,int *);
int addNode(voteCube *,treeLink **,float,int,int);
void copyUpwards(treeLink *,int);
void addNodes(treeLink **,listLink *,int);
void makeTree(treeLink *,listLink *);
treeLink *findTop(treeLink *,float,float);
void visit(treeLink *,voteCube *);
void exploreBranch(treeLink *,vector,vector,voteCube *,float,int,int);
void treeQuery(treeLink *,vector,vector,voteCube *,int);
void useQueryOutput(voteCube *,voteCube *);
void smooth(int,int);
void chooseBest(int);
void sortBest();
void computeDifferences();
void printResults(int);

//=================================================================================================================================================
//=================================================================== :: main :: ==================================================================
//=================================================================================================================================================
int main() {

    FILE *Fprotein;
    FILE *Fobject;
    FILE *Fobjs;
    int mm;  //Model protein number
    int m;   //Model protein chain number
    int oo;  //Object protein number
    int o;   //Object protein chain number
    char filepath[100];
    chain *mmm; //Chain m of protein mm
    
    memset(filepath,0,100);
    mmm=(chain *)(malloc(sizeof(chain)));
    if (motifmode) {
        invmode=1;
        Fobjs=fopen(".\\motif.list","r");
    } else {
        Fobjs=fopen(".\\object.list","r");
    }
    Fcoverage=fopen(".\\results\\5b.coverage.txt","w");
    Favg=fopen(".\\results\\5b.avg.txt","w");
    
    objectprotein=0;
    
    makeCount();
    readParameters();
    
    for (oo=1; oo<=OO; oo++) {    //CYCLE ON THE OBJECT PROTEINS
    
        sparse=0;
        
        allocateStructures();
        
        //Creation of the path for OBJECT protein number oo
        if (motifmode) {
            strcpy(filepath,".\\msecondary\\");
        } else {
            strcpy(filepath,".\\proteinMerge\\");
        }
        fscanf(Fobjs,"%s\n",oos);
        strcat(filepath,oos);
                //reading of data on chains in object protein from corresponding file
        Fobject=fopen(filepath,"r");
        fscanf(Fobject,"%d\n\n",&O);
        if (objectprotein) free(objectprotein);
        objectprotein=(chain *)(malloc(O*sizeof(chain)));
        
        if (!(O)) {
            fclose(Fobject);
            continue;
        }
        
        if (adaptivemode) {
            //in ADAPTIVE-mode, calculation of spacemesh and phimesh on the basis of O, the number of chains on the object protein
            if (O<8) {
                spacemesh = 1.0; meshreg = 1; phimesh = 50;
            } else if (O<15) {
                spacemesh = 1.0; meshreg = 1; phimesh = 30;
            } else if (O<25) {
                spacemesh = 1.0; meshreg = 1; phimesh = 30;
            } else {
                spacemesh = 1.0; meshreg = 1; phimesh = 10;
            }
            strcpy(adaptivelabel,"(5331,1111)");
        }
            
        for (o=1;o<=O;o++) {       //cycle on the chains of the Fobject Fprotein
            fscanf(Fobject,"%s\n",&((*(objectprotein+o-1)).type));
            fscanf(Fobject,"%d\n",&((*(objectprotein+o-1)).len));
            fscanf(Fobject,"%f\t%f\t%f\n",&((*(objectprotein+o-1)).pos.x),&((*(objectprotein+o-1)).pos.y),&((*(objectprotein+o-1)).pos.z));
            fscanf(Fobject,"%f\t%f\t%f\n",&((*(objectprotein+o-1)).dir.x),&((*(objectprotein+o-1)).dir.y),&((*(objectprotein+o-1)).dir.z));
            fscanf(Fobject,"%f\n",&((*(objectprotein+o-1)).rho));
            fscanf(Fobject,"%f\n",&((*(objectprotein+o-1)).theta));
        }
        fclose(Fobject);
        for (mm=1;mm<=MM;mm++) {                //CYCLE ON THE MODEL PROTEINS
            
            freeEverything();        //Free heap memory
            cubes=0;
            lastcube=0;
            dim1=0;
            rangetree=0;
            
            //Creation of filepath for MODEL Fprotein number mm
            strcpy(filepath,".\\proteinMerge\\");
            strcat(filepath,mms[mm-1]);
            Fprotein=fopen(filepath,"r");        //Open in read-mode of model Fprotein number mm
            
            fscanf(Fprotein,"%d\n\n",&(M[mm-1]));  //Reading of M
            
            if (!(M[mm-1])) {
                continue;
            }
            
            
            if (skipself) {
                if (!(strcmp(oos,mms[mm-1]))) {
                    printf("Comparing: (%d/%d) \"%s\" with (%d/%d) \"%s\" --SKIPPED--",oo,OO,oos,mm,MM,mms[mm-1]);
                    continue;
                } else {
                    printf("Comparing: (%d/%d) \"%s\" with (%d/%d) \"%s\"",oo,OO,oos,mm,MM,mms[mm-1]);
                }
            } else {
                printf("Comparing: (%d/%d) \"%s\" with (%d/%d) \"%s\"",oo,OO,oos,mm,MM,mms[mm-1]);
            }
            printf(" (%d)",M[mm-1]);
            
            
            for (m=1;m<=M[mm-1];m++) {                        //CYCLE ON THE M CHAINS OF MODEL PROTEIN mm
                //Reading of dana on chain m of model Fprotein mm
                fscanf(Fprotein,"%s\n",&(mmm->type));
                fscanf(Fprotein,"%d\n",&(mmm->len));
                fscanf(Fprotein,"%f\t%f\t%f\n",&(mmm->pos.x),&(mmm->pos.y),&(mmm->pos.z));
                fscanf(Fprotein,"%f\t%f\t%f\n",&(mmm->dir.x),&(mmm->dir.y),&(mmm->dir.z));
                fscanf(Fprotein,"%f\n",&(mmm->rho));
                fscanf(Fprotein,"%f\n\n",&(mmm->theta));
                for (o=1;o<=O;o++) {                    //CYCLE ON THE O CHAINS OF THE OBJECT PROTEIN
                    //Voting procedure (CYCLE ON PHI)
                    vote(o,mmm,mm);
                }
            }
            
            printf(".");
            //Smoothing within radius "mulsum*sumdist" from the center of the cube and subsequent sorting by cumulated vote of the cubes (in another vector)
            davg=0;
            smooth(mm,M[mm-1]);
            
            davg/=dim1;
            favg=(float)(davg);
            if (debug7) {
                fprintf(Favg,"%s\t%f\n",mms[mm-1],favg);
            }
            
            //Choice of the best: placement of the first permodel votes if the Fprotein (which at the same time aren't far more than "bestdist"
            //from one another) in the "best" cubes
            chooseBest(mm);
            printf(".\n");
            fclose(Fprotein);
        }
        
        sortBest();
        computeDifferences();
        printResults(oo);
    }
    
    
    if (!motifmode) {
        fclose(Freport);
    }
    fclose(Freportplus);
    fclose(Fobjs);
    fclose(Fcoverage);
    fclose(Favg);
    
    if (debug6) while (true);
    
    return 0;
}


//=================================================================================================================================================
//================================================================ :: freeList :: =================================================================
//=================================================================================================================================================
void freeList(listLink *node) {
    listLink *scroll;
    listLink *scrollnext;
    
    scroll=node;
    while (scroll) {
        scrollnext=scroll->next;
        free(scroll);
        scroll=scrollnext;
    }
}

//=================================================================================================================================================
//================================================================ :: freeTree :: =================================================================
//=================================================================================================================================================
void freeTree(treeLink *node) {
    if (node) {
        freeList(node->cubes);
        if (node->ltree) freeTree(node->ltree);
        if (node->rtree) freeTree(node->rtree);
        if (node->utree) freeTree(node->utree);
        free(node);
    }
}

//=================================================================================================================================================
//============================================================= :: freeEverything :: ==============================================================
//=================================================================================================================================================
void freeEverything() {
    listLink *scroll;
    listLink *scrollnext;

    scroll=cubes;
    while (scroll) {
        scrollnext=scroll->next;
        freeList(scroll->cube->neighbors);
        free(scroll->cube);
        scroll=scrollnext;
    }
    freeList(cubes);
    freeTree(rangetree);
}

//=================================================================== :: dot :: ===================================================================
float dot(vector a, vector b) {
    return (a.x*b.x+a.y*b.y+a.z*b.z);
}

//================================================================== :: cross :: ==================================================================
void cross(vector a, vector b, vector *result) {
    (result->x)=a.y*b.z-a.z*b.y;
    (result->y)=-(a.x*b.z-a.z*b.x);
    (result->z)=a.x*b.y-a.y*b.x;
}

//================================================================ :: normalize :: ================================================================
void normalize(vector *a) {
    float norm=sqrt(dot(*a,*a));
    (a->x)=(a->x)/norm;
    (a->y)=(a->y)/norm;
    (a->z)=(a->z)/norm;
}

//================================================================= :: compare :: =================================================================
int compare(vector a, vector b) {
    if (a.x>b.x) {
        return 1;
    } else {
        if (a.x==b.x) {
            if (a.y>b.y) {
                return 1;
            } else {
                if (a.y==b.y) {
                    if (a.z>b.z) {
                        return 1;
                    } else {
                        if (a.z==b.z) {
                            return 0;
                        } else {
                            return -1;
                        }
                    }
                } else {
                    return -1;
                }
            }
        } else {
            return -1;
        }
    }
}


//=============================================================== :: distance :: ==================================================================
float distance(vector a, vector b) {
    vector diff;
    float dist;
    
    diff.x=a.x-b.x;
    diff.y=a.y-b.y;
    diff.z=a.z-b.z;
    dist=sqrt(dot(diff,diff));
    return dist;
}

//=========================================================== :: makeVotePosition :: ==============================================================
void makeVotePosition(vector a, vector *output) {
    
    struct doublevector {
        double x;
        double y;
        double z;
    } result;
    
    double fractpart;
    int cnt;
    
    result.x=a.x/spacemesh;
    result.y=a.y/spacemesh;
    result.z=a.z/spacemesh;
    fractpart = modf(result.x,&(result.x));
    fractpart = modf(result.y,&(result.y));
    fractpart = modf(result.z,&(result.z));
    result.x*=spacemesh;
    result.y*=spacemesh;
    result.z*=spacemesh;
    for (cnt=1;cnt<=meshreg;cnt++) {
        if ((a.x-result.x)>0.8*spacemesh) { result.x+=spacemesh; }
        if ((a.y-result.y)>0.8*spacemesh) { result.y+=spacemesh; }
        if ((a.z-result.z)>0.8*spacemesh) { result.z+=spacemesh; }
    }
    (output->x)=(float)(result.x);
    (output->y)=(float)(result.y);
    (output->z)=(float)(result.z);
}

//============================================================= :: rototranslate :: ===============================================================
void rototranslate(vector pos, vector *rotate, vector translate, vector *newposition) {
    newposition->x=rotate[0].x*pos.x+rotate[1].x*pos.y+rotate[2].x*pos.z;
    newposition->y=rotate[0].y*pos.x+rotate[1].y*pos.y+rotate[2].y*pos.z;
    newposition->z=rotate[0].z*pos.x+rotate[1].z*pos.y+rotate[2].z*pos.z;
    newposition->x+=translate.x;
    newposition->y+=translate.y;
    newposition->z+=translate.z;
}

//=================================================================================================================================================
//=============================================================== :: makeCount :: =================================================================
//=================================================================================================================================================
void makeCount() {
    FILE *Fcount;
    FILE *Fobjs;
    FILE *Fmdls;
    int obj,mdl;
    char filename[80];
    
    Fcount=fopen("count.list","w");
    if (motifmode) {
        Fobjs=fopen("motif.list","r");
        Fmdls=fopen("all.list","r");
    } else {
        Fobjs=fopen("object.list","r");
        Fmdls=fopen("model.list","r");
    }

    obj=0;
    while (!(feof(Fobjs))) {
        fscanf(Fobjs,"%s\n",filename);
        obj++;
    }
    
    mdl=0;
    while (!(feof(Fmdls))) {
        fscanf(Fmdls,"%s\n",filename);
        mdl++;
    }
    
    fprintf(Fcount,"%d\n%d\nObjects\nModels\n",obj,mdl);
    
    fclose(Fcount);
    fclose(Fobjs);
    fclose(Fmdls);
}

//=================================================================================================================================================
//============================================================ :: readParameters :: ===============================================================
//=================================================================================================================================================
void readParameters() {
    FILE *Fcount;
    FILE *Fmodels;
    int counter;
    
    
    Fcount=fopen("count.list","r");
    fscanf(Fcount,"%d\n",&OO);
    fscanf(Fcount,"%d\n",&MM);
    fclose(Fcount);
    
    mms=(char **)(malloc(MM*sizeof(char *)));
    if (motifmode) {
        Fmodels=fopen("all.list","r");
    } else {
        Fmodels=fopen("model.list","r");
    }
    for (counter=1; counter<=MM; counter++) {
        mms[counter-1]=(char *)(malloc(12*sizeof(char)));
        fscanf(Fmodels,"%s\n",mms[counter-1]);
    }
    fclose(Fmodels);
}

//=================================================================================================================================================
//========================================================= :: allocateStructures :: ==============================================================
//=================================================================================================================================================
void allocateStructures() {
    dim3=permodel*MM;
    best=(voteCube **)(malloc(dim3*sizeof(voteCube *)));
    memset(best,0,dim3*sizeof(voteCube *));
    bestsort=(voteCube **)(malloc(dim3*sizeof(voteCube *)));
    memset(bestsort,0,dim3*sizeof(voteCube *));
    diffptrs=(voteCube **)(malloc(MM*sizeof(voteCube *)));
    memset(diffptrs,0,MM*sizeof(voteCube *));
    difference=(float *)(malloc(MM*sizeof(float)));
    memset(difference,0,MM*sizeof(float));
    M=(int *)(malloc(MM*sizeof(int)));
    memset(M,0,MM*sizeof(int));
}

//=================================================================================================================================================
//================================================================= :: vote :: ====================================================================
//=================================================================================================================================================
void vote(int o, chain *mmm, int mm) {
    
    //mmm is the m chain of model protein mm
    
    char objtype[20];
    int objlen;
    vector objpos;
    vector objdir;
    float objrho;
    float objtheta;
    vector firstvote;
    vector lastvote;
    int firstmatch;
    int lastmatch;
    float phi;
    voteCube *newcube;
    voteCube *current;
    vector *rotate;
    vector point;
    vector pointToVote;
    listLink *newcubelink;
    
    
    rotate=(vector *)(malloc(3*sizeof(vector)));
    strcpy(objtype,(*(objectprotein+o-1)).type);
    objlen=(*(objectprotein+o-1)).len;
    objpos.x=(*(objectprotein+o-1)).pos.x;
    objpos.y=(*(objectprotein+o-1)).pos.y;
    objpos.z=(*(objectprotein+o-1)).pos.z;
    objdir.x=(*(objectprotein+o-1)).dir.x;
    objdir.y=(*(objectprotein+o-1)).dir.y;
    objdir.z=(*(objectprotein+o-1)).dir.z;
    objrho=(*(objectprotein+o-1)).rho;
    objtheta=(*(objectprotein+o-1)).theta;
        
    phi=0;
    lastmatch=0;
    do {
        //=====================
        //CREATION OF VOTE CUBE
        //=====================
                
        //Make a new heap memory area that will be inserted in the cubes cubes
        newcube=(voteCube *)(malloc(sizeof(voteCube)));
        //Computation of the coordinates of the point to be voted with respect to the x axis
        
        //====ATTENTION==== here who gives rho and theta is set: the model Fprotein (DIR mode) or the Fobject Fprotein (INV mode)
        point.x=(invmode?objrho:(mmm->rho))*cos(invmode?objtheta:(mmm->theta));
        point.y=(invmode?objrho:(mmm->rho))*sin(invmode?objtheta:(mmm->theta))*cos(phi);
        point.z=(invmode?objrho:(mmm->rho))*sin(invmode?objtheta:(mmm->theta))*sin(phi);
        
        //Calculate the rotation matrix which transforms the x dir into the dir of the chain in the Fobject (or model) Fprotein space
        //====ATTENTION==== here who gives the dir of rotation of the voting cone is set: the Fobject Fprotein (DIR mode) or the model Fprotein (INV mode)
        rotate[0].x=invmode?(mmm->dir.x):(objdir.x);
        rotate[0].y=invmode?(mmm->dir.y):(objdir.y);
        rotate[0].z=invmode?(mmm->dir.z):(objdir.z);
        
        rotate[2].x=rotate[0].x-1;
        rotate[2].y=rotate[0].y;
        rotate[2].z=rotate[0].z;
        normalize(&(rotate[2]));
        cross(rotate[2],rotate[0],&(rotate[1]));
        normalize(&(rotate[1]));
        cross(rotate[0],rotate[1],&(rotate[2]));
        //Trasform of the coordinates to put them in the space of the Fobject (or model) Fprotein
        //====ATTENTION==== here who gives the pos for translation of the voting cone is set:
        //================= the Fobject Fprotein (DIR mode) or the model Fprotein (INV mode)
        rototranslate(point,rotate,(invmode?(mmm->pos):objpos),&pointToVote);
        //Discretization of the voting pos for research and voting
        makeVotePosition(pointToVote,&pointToVote);
        //WARNING: IT'S NOT LIKE THIS ANYMORE
        //Making the vote. The voting cube will be added as such if non-existing, otherwise the vote will be summed in the corresponding area
        newcube->pos.x=pointToVote.x;
        newcube->pos.y=pointToVote.y;
        newcube->pos.z=pointToVote.z;
        //In the following line the mode (DIR or INV) doesn't affect anything, since it's a comparison or a squared difference
        newcube->pointvote=singlevote*((strcmp(objtype,(mmm->type))==0)?1:typewt)*(exp(-pow(lenwt*(objlen-(mmm->len)),2)));
        newcube->mm=mm;
        newcube->neighbors=0;
        newcube->lastneighbor=0;
        if (!phi) {
            firstvote.x=pointToVote.x;
            firstvote.y=pointToVote.y;
            firstvote.z=pointToVote.z;
        }
        
        //IN VERSION 2 RESEARCH OF VOTING POSITION DOESN'T DO!! VOTING MUST BE DONE BY AVOIDING DUPLICATES AND UPDATING ADJACENCY LISTS.
        //THE NEW SMOOTHING PROCEDURE WILL DO THE REST.
        
        firstmatch=((firstvote.x==pointToVote.x)&&(firstvote.y==pointToVote.y)&&(firstvote.z==pointToVote.z));
        if (phi>0) {
            lastmatch=((lastvote.x==pointToVote.x)&&(lastvote.y==pointToVote.y)&&(lastvote.z==pointToVote.z));
        }
        //If the first vote in the circle, or another vote but the pos isn't not the first nor the one just voted,
        if ((phi<2*pi/phimesh)||((phi>0)&&(!firstmatch)&&(!lastmatch))) {
            //VOTE: IF THE LIST IS EMPTY, START IT, OTHERWISE APPEND
            newcubelink=(listLink *)(malloc(sizeof(listLink)));
            newcubelink->next=0;
            newcubelink->cube=newcube;
            if (cubes) {
                lastcube->next=newcubelink;
                lastcube=newcubelink;
            } else {
                lastcube=(cubes=newcubelink);
            }
            dim1++;
        } else {
            free(newcube);
            //DON'T APPEND: IT'S AN ALREADY WRITTEN VOTE - ONLY DELETE THE HEAP AREA
        }
        lastvote.x=pointToVote.x;
        lastvote.y=pointToVote.y;
        lastvote.z=pointToVote.z;
        
        phi+=2*pi/phimesh;
    } while (phi<(2*pi));
    free(rotate);
}

//=================================================================================================================================================
//================================================================= :: push :: ====================================================================
//=================================================================================================================================================
void push(stackLink **stacktop,treeLink **treevertex,int delta) {
    stackLink *underneath;
    
    underneath=*stacktop;
    *stacktop=(stackLink *)(malloc(sizeof(stackLink)));
    (*stacktop)->inner=underneath;
    (*stacktop)->treevertex=treevertex;
    (*stacktop)->delta=delta;
}

//=================================================================================================================================================
//================================================================= :: pull :: ====================================================================
//=================================================================================================================================================
treeLink **pull(stackLink **stacktop,int *delta) {
    treeLink **topull;
    stackLink *toclear;
    
    if ((*stacktop)==0) {
        return 0;
    }
    topull=(*stacktop)->treevertex;
    *delta=(*stacktop)->delta;
    toclear=*stacktop;
    *stacktop=(*stacktop)->inner;
    free(toclear);
    return topull;
}

//=================================================================================================================================================
//============================================================== :: emptystack :: =================================================================
//=================================================================================================================================================
void emptystack(stackLink **stacktop) {
    treeLink **pulled;
    int buffer;
    
    while (*stacktop) {
        pulled=pull(stacktop,&buffer);
    }
}

//=================================================================================================================================================
//=============================================================== :: lookfor :: ===================================================================
//=================================================================================================================================================
int lookfor(treeLink **subTree,float key,treeLink ***addhere,int *totheright,stackLink **stacktop) {
    int match;
    
    if (!(*subTree)) {
        *addhere=subTree;
        return -1;
    }
    if ((*subTree)->isleaf) {
        *addhere=subTree;
        match=((key-((*subTree)->key)<0)?(((*subTree)->key)-key<0.1*spacemesh):(key-((*subTree)->key)<0.1*spacemesh));
        *totheright=(key>((*subTree)->key)); //this will be used only whether match be ==0
        return match;
    }
    if (key>((*subTree)->key)) {
        push(stacktop,subTree,1);
        return lookfor(&((*subTree)->rtree),key,addhere,totheright,stacktop);
    } else {
        push(stacktop,subTree,-1);
        return lookfor(&((*subTree)->ltree),key,addhere,totheright,stacktop);
    }
}

//=================================================================================================================================================
//================================================================= :: rrot :: ====================================================================
//=================================================================================================================================================
void rrot(treeLink **parent) {
    treeLink *root;
    treeLink *pivot;
    
    root=*parent;
    pivot=root->ltree;
    root->bal+=1-(pivot->bal<0?pivot->bal:0);
    pivot->bal+=1+(root->bal>0?root->bal:0);
    root->ltree=pivot->rtree;
    pivot->rtree=root;
    (*parent)=pivot;
}

//=================================================================================================================================================
//================================================================= :: lrot :: ====================================================================
//=================================================================================================================================================
void lrot(treeLink **parent) {
    treeLink *root;
    treeLink *pivot;
    
    root=*parent;
    pivot=root->rtree;
    root->bal-=1+(pivot->bal>0?pivot->bal:0);
    pivot->bal-=1-(root->bal<0?root->bal:0);
    root->rtree=pivot->ltree;
    pivot->ltree=root;
    (*parent)=pivot;
}

//=================================================================================================================================================
//============================================================== :: rebalance :: ==================================================================
//=================================================================================================================================================
void rebalance(treeLink **parent) {
    treeLink *root;
    
    root=*parent;
    if (root->bal==2) {  //leaning to the right
        if (root->rtree->bal==1) { //right-right: single left rotation
            lrot(parent);
        } else {                    //right-left: right rotation, then left rotation
            rrot(&(root->rtree));
            lrot(parent);
        }
    } else {             //..to the left
        if (root->ltree->bal==-1) { //left-left: single right rotation
            rrot(parent);
        } else {                    //left-right: left rotation, then right rotation
            lrot(&(root->ltree));
            rrot(parent);
        }
    }
}

//=================================================================================================================================================
//=============================================================== :: addNode :: ===================================================================
//=================================================================================================================================================
int addNode(voteCube *element,treeLink **father,float key,int found,int totheright,int depth,stackLink **stacktop) {
    //First off, the following cases are to be skimmed off:
    // - the father is pointing a null element (found==-1); here, the father must point a newly created leaf with the element
    // - the element was found and the coordinate given as key is already present (found==1)
    //The remaining case (found==0) is that of a leaf to be split into two ones by repointing the father to a newly created internal node
    //and making the latter father of the old leaf and the new one in its turn. In this case, "totheright" tells whether to put the newer element
    //to the right or to the left with respect to the old leaf
    treeLink *newvertex;
    treeLink *newinnervertex;
    listLink *newlistlink;
    treeLink **pulled;
    int stopclimbing;
    int delta;
    
    newlistlink=(listLink *)(malloc(sizeof(listLink)));
    newlistlink->next=0;
    newlistlink->cube=element;
    if (found==1) {
        (*father)->lastcube->next=newlistlink;
        (*father)->lastcube=newlistlink;
    } else {
        newvertex=(treeLink *)(malloc(sizeof(treeLink)));
        newvertex->lastcube=(newvertex->cubes=newlistlink);
        newvertex->isleaf=1;
        newvertex->bal=0;
        newvertex->key=key;
        newvertex->utree=0;
        newvertex->ltree=0;
        newvertex->rtree=0;
        if (found==-1) {
            (*father)=newvertex;
        } else if (found==0) {
            newinnervertex=(treeLink *)(malloc(sizeof(treeLink)));
            newinnervertex->isleaf=0;
            newinnervertex->bal=0;
            newinnervertex->cubes=(newinnervertex->lastcube=0);
            newinnervertex->utree=0;
            if (totheright) {
                newinnervertex->key=(*father)->key;
                newinnervertex->ltree=(*father);
                newinnervertex->rtree=newvertex;
            } else {
                newinnervertex->key=key;
                newinnervertex->ltree=newvertex;
                newinnervertex->rtree=(*father);
            }
            (*father)=newinnervertex;
            //Climb up and recalculate balance parameters; if there's unbalance, call rotation.
            stopclimbing=0;
            if (*stacktop) {
                do {
                    pulled=pull(stacktop,&delta);
                    (*pulled)->bal+=delta;
                    if ((*pulled)->bal==0) {
                        stopclimbing=1;
                    }
                    if (((*pulled)->bal==2)||((*pulled)->bal==-2)) {
                        rebalance(pulled);
                        stopclimbing=1;
                    }
                } while ((*stacktop)&&(!stopclimbing));
            }
        }
    }
}

//=================================================================================================================================================
//============================================================= :: copyUpwards :: =================================================================
//=================================================================================================================================================
void copyUpwards(treeLink *subTree,int depth) {
    listLink *leftlist;
    listLink *rightlist;
    listLink *newlistlink;
    listLink *current;
    int i;
    
    if ((subTree)&&(depth<=2)) {
        if (!(subTree->isleaf)) {
            copyUpwards(subTree->ltree,depth);
            copyUpwards(subTree->rtree,depth);
            leftlist=subTree->ltree->cubes;
            rightlist=subTree->rtree->cubes;
            current=leftlist;
            for (i=0; i<=1; i++) {
                while (current) {
                    newlistlink=(listLink *)(malloc(sizeof(listLink)));
                    newlistlink->next=0;
                    newlistlink->cube=current->cube;
                    if (subTree->cubes) {
                        subTree->lastcube->next=newlistlink;
                        subTree->lastcube=newlistlink;
                    } else {
                        subTree->lastcube=(subTree->cubes=newlistlink);
                    }
                    current=current->next;
                }
                current=rightlist;
            }    
        }
        addNodes(&(subTree->utree),subTree->cubes,depth+1);
    }
}

//=================================================================================================================================================
//=============================================================== :: addNodes :: ==================================================================
//=================================================================================================================================================
void addNodes(treeLink **subTree,listLink *cubes,int depth) {
    listLink *listScroller;
    float newkey;
    int found;
    int totheright;
    treeLink **addhere;
    stackLink *localstacktop;
    
    localstacktop=(stackLink *)0;
    listScroller=cubes;
    while (listScroller) {
        emptystack(&localstacktop);
        if (depth==1) {
            newkey=listScroller->cube->pos.x;
        } else if (depth==2) {
            newkey=listScroller->cube->pos.y;
        } else if (depth==3) {
            newkey=listScroller->cube->pos.z;
        }
        found=lookfor(subTree,newkey,&addhere,&totheright,&localstacktop);
        addNode(listScroller->cube,addhere,newkey,found,totheright,depth,&localstacktop);
        listScroller=listScroller->next;
    }
    copyUpwards(*subTree,depth);
}

//=================================================================================================================================================
//=============================================================== :: makeTree :: ==================================================================
//=================================================================================================================================================
void makeTree(treeLink **rangetree,listLink *cubes) {
    addNodes(rangetree,cubes,1);
}

//=================================================================================================================================================
//============================================================ :: useQueryOutput :: ===============================================================
//=================================================================================================================================================
void useQueryOutput(voteCube *output,voteCube *current) {
    listLink *newneighbor;
    
    if (distance(current->pos,output->pos)<=mulsum*sumdist) {
        //Add cube on current
        newneighbor=(listLink *)(malloc(sizeof(listLink)));
        if (!(current->neighbors)) {
            current->neighbors=newneighbor;
        } else {
            current->lastneighbor->next=newneighbor;
        }
        current->lastneighbor=newneighbor;
        newneighbor->cube=output;
        newneighbor->next=0;
    }
}

//=================================================================================================================================================
//================================================================ :: visit :: ====================================================================
//=================================================================================================================================================
void visit(treeLink *subTree,voteCube *current) {
    listLink *scroller;
    
    if (subTree->isleaf) {
        scroller=subTree->cubes;
        while (scroller) {
            useQueryOutput(scroller->cube,current);
            scroller=scroller->next;
        }
    } else {
        visit(subTree->ltree,current);
        visit(subTree->rtree,current);
    }
}

//=================================================================================================================================================
//============================================================ :: exploreBranch :: ================================================================
//=================================================================================================================================================
void exploreBranch(treeLink *subTree,vector lower,vector upper,voteCube *current,float key,int leftbranch,int depth) {
    listLink *scroller;
    
    if (leftbranch) {
        if (subTree->isleaf) {
            if (key<=subTree->key) {
                if (depth==3) {
                    visit(subTree,current);
                } else {
                    treeQuery(subTree->utree,lower,upper,current,depth+1);
                }
            } else {
                //do nothing
            }
        } else {
            if (key<=subTree->key) {
                if (depth==3) {
                    visit(subTree->rtree,current);
                    exploreBranch(subTree->ltree,lower,upper,current,key,leftbranch,depth);
                } else {
                    treeQuery(subTree->rtree->utree,lower,upper,current,depth+1);
                    exploreBranch(subTree->ltree,lower,upper,current,key,leftbranch,depth);
                }
            } else {
                exploreBranch(subTree->rtree,lower,upper,current,key,leftbranch,depth);
            }
        }
    } else {
        if (subTree->isleaf) {
            if (key>=subTree->key) {
                if (depth==3) {
                    visit(subTree,current);
                } else {
                    treeQuery(subTree->utree,lower,upper,current,depth+1);
                }
            } else {
                //do nothing
            }
        } else {
            if (key>subTree->key) {
                if (depth==3) {
                    visit(subTree->ltree,current);
                    exploreBranch(subTree->rtree,lower,upper,current,key,leftbranch,depth);
                } else {
                    treeQuery(subTree->ltree->utree,lower,upper,current,depth+1);
                    exploreBranch(subTree->rtree,lower,upper,current,key,leftbranch,depth);
                }
            } else {
                exploreBranch(subTree->ltree,lower,upper,current,key,leftbranch,depth);
            }
        }
    }
}

//=================================================================================================================================================
//=============================================================== :: findTop :: ===================================================================
//=================================================================================================================================================
treeLink *findTop(treeLink *subTree,float leftkey,float rightkey) {
    if ((leftkey<=subTree->key)&&(rightkey>subTree->key)) return subTree;
    if (subTree->isleaf) return (treeLink *)-1;
    if (leftkey>subTree->key) return findTop(subTree->rtree,leftkey,rightkey);
    if (rightkey<=subTree->key) return findTop(subTree->ltree,leftkey,rightkey);
}

//=================================================================================================================================================
//============================================================== :: treeQuery :: ==================================================================
//=================================================================================================================================================
void treeQuery(treeLink *subTree,vector lower,vector upper,voteCube *current,int depth) {
    float leftkey;
    float rightkey;
    treeLink *top;
    
    if (depth==1) {
        leftkey=lower.x;
        rightkey=upper.x;
    } else if (depth==2) {
        leftkey=lower.y;
        rightkey=upper.y;
    } else if (depth==3) {
        leftkey=lower.z;
        rightkey=upper.z;
    }
    
    top=findTop(subTree,leftkey,rightkey);
    if ((int)top!=-1) {
        if (top->isleaf) {
            if (depth==3) {
                visit(subTree,current);
            } else {
                treeQuery(subTree->utree,lower,upper,current,depth+1);
            }
        } else {
            exploreBranch(top->ltree,lower,upper,current,leftkey,1,depth);
            exploreBranch(top->rtree,lower,upper,current,rightkey,0,depth);
        }
    }
}

//=================================================================================================================================================
//================================================================== :: smooth :: =================================================================
//=================================================================================================================================================
void smooth(int mm, int M) {  //mm is the model protein number, M is the number of chains of model protein number mm
    
    listLink *current;
    listLink *scroll;
    vector lower;
    vector upper;
    int dbcounter;
    
    //COMPILE ADJACENCIES CREATING THE TREE AND QUERYING IT
    //Create the search structure
    makeTree(&rangetree,cubes);
    printf(".");
        
    current=cubes;
    while (current) {
        //Compute the two extremes of the cube for the smoothing range
        
        lower.x=current->cube->pos.x-mulsum*sumdist;
        lower.y=current->cube->pos.y-mulsum*sumdist;
        lower.z=current->cube->pos.z-mulsum*sumdist;
        upper.x=current->cube->pos.x+mulsum*sumdist;
        upper.y=current->cube->pos.y+mulsum*sumdist;
        upper.z=current->cube->pos.z+mulsum*sumdist;
        //Query the tree and for each output, evaluate if the element is internal to the sphere and add as listLink in the cubes of both the votes
        treeQuery(rangetree,lower,upper,current->cube,1);
        current=current->next;
    }    
            
    //SMOOTH USING THE ADJACENCIES JUST WRITTEN
    current=cubes;
    
    while (current) {
        current->cube->smoothedvote=0;
        scroll=current->cube->neighbors;
        dbcounter=0;
        while (scroll) {
            current->cube->smoothedvote+=scroll->cube->pointvote;
            dbcounter++;
            scroll=scroll->next;
        }
        davg+=current->cube->pointvote;
        current->cube->smoothedvote/=singlevote*spherediam*((R==4)?(1/M):((R==3)?1:(R?((R==2)?((M<O)?M:O):(sqrt(M))):M)));
                                                //to know the coverage, it is necessary to divide the smoothedvote by the value of one vote,
                                                //by the diameter (in number of spacemesh) of the inclusion sphere of radius "mulsum*sumdist"
                                                //and by M, the number of chains in the model protein
                                                //ATTENTION: M penalizes long proteins.. changing to sqrt(M)
                                                //Idea had in Padua: divide by M if M<=O, otherwise divide by O: in this way
                                                //the model protein is searched a substructure of the Fobject Fprotein (M<O). Otherwise proteins
                                                //might be similar in size (M~O). Otherwise, the object protein is searched as substructure of the
                                                //model protein, but in this case the division by more than O is not to be done, since as the voting space
                                                //is the object protein space, max O circumferences could overlap in a vote
                                                //BUT.. I SHOULD DO THE OPPOSITE: DIVIDE BY M, TO DIMINISH THE VOTE DENSITY IN CASE OF BIG MODEL PROTEINS
                                                //THAT VOTE TOO MUCH. THE FACT THAT O CIRCUMFERENCES MAX COULD OVERLAP IS SOMETHING THAT MUSTN'T BE TOUCHED, SINCE
                                                //IT'S WHAT GUARANTEES THE RIGHT PROCEDURE OF FORMATION OF VOTE PEAKS --> ALL THIS REFERS TO DIR MODE CASE
        current->cube->smoothedvote*=100;
        current=current->next;
    }
    
    
    if (debug1) {
        int theor;
        float cover;
        
        theor=O*M*phimesh;
        cover=(float)dim1/(float)theor;
        fprintf(Fcoverage,"%d\t%d\t%f\t%s\n",dim1,theor,cover,mms[mm-1]);
    }
}


//=================================================================================================================================================
//================================================================ :: chooseBest :: ===============================================================
//=================================================================================================================================================
void chooseBest(int mm) {
    
    voteCube *top;
    listLink *scroll;
    voteCube *check;
    voteCube *cmp;
    voteCube *temp;
    int cnt;
    int proceed;
    int spy;
    int mov;
    
    scroll=cubes;
    while (scroll) {
        for (cnt=permodel*(mm-1); cnt<=permodel*mm-1; cnt++) {
            top=*(best+cnt);
            if (top) {
                if (scroll->cube->smoothedvote>top->smoothedvote) {
                    //check the "best" cubes, if there are better neighbors don't add, otherwise: scroll the "best" cubes,
                    //temporarily putting the last on a temporary pointer, then add, then delete those neighbors with a lower vote, scrolling
                    //each time towards the top (and writing 0 on the temporary pointer after scrolling for the first time)
                    proceed=1;
                    for (spy=permodel*(mm-1); spy<cnt; spy++) {
                        check=*(best+spy);
                        if (check) {
                            if (distance(check->pos,scroll->cube->pos)<muldist*bestdist) {
                                proceed=0;
                            }
                        }
                    }
                    if (proceed) {
                        //scroll the cubes downwards, using a temporary pointer
                        temp=*(best+(permodel*mm-1));
                        mov=permodel*mm-1;
                        mov--;
                        while (mov>=cnt) {
                            *(best+mov+1)=*(best+mov);
                            mov--;
                        }
                        //add
                        top=(*(best+cnt)=(voteCube *)(malloc(sizeof(voteCube))));
                        top->smoothedvote=scroll->cube->smoothedvote;
                        top->mm=scroll->cube->mm;
                        top->pos.x=scroll->cube->pos.x;
                        top->pos.y=scroll->cube->pos.y;
                        top->pos.z=scroll->cube->pos.z;
                        top->pointvote=scroll->cube->pointvote;
                        //delete
                        if (cnt!=permodel*mm-1) {
                            for (spy=cnt+1; spy<=permodel*mm-1; spy++) {
                                check=*(best+spy);
                                if (check) {
                                    if (distance(check->pos,top->pos)<muldist*bestdist) {
                                        //delete and scroll
                                        for (mov=spy; mov<=permodel*mm-1; mov++) {
                                            if (mov==permodel*mm-1) {
                                                *(best+mov)=temp;
                                                temp=0;
                                            } else {
                                                *(best+mov)=*(best+mov+1);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
                if (scroll->cube->smoothedvote<top->smoothedvote) { 
                    //scroll the "best" cubes (simply by letting the for cycle proceed)
                }
            } else {
                //if a vote does NOT exist, it has to be written on the cubes, provided there aren't any near votes, then interrupt scrolling
                //check that the previous areas are not near, otherwise don't add
                proceed=1;
                for (spy=permodel*(mm-1); spy<cnt; spy++) {
                    check=*(best+spy);
                    if (check) {
                        if (distance(check->pos,scroll->cube->pos)<muldist*bestdist) {
                            proceed=0;
                        }
                    }
                }
                if (proceed) {
                    top=(*(best+cnt)=(voteCube *)(malloc(sizeof(voteCube))));
                    top->smoothedvote=scroll->cube->smoothedvote;
                    top->mm=scroll->cube->mm;
                    top->pos.x=scroll->cube->pos.x;
                    top->pos.y=scroll->cube->pos.y;
                    top->pos.z=scroll->cube->pos.z;
                    top->pointvote=scroll->cube->pointvote;
                }
                break;
            }
        }
        scroll=scroll->next;
    }
}

//=================================================================================================================================================
//================================================================= :: sortBest :: ================================================================
//=================================================================================================================================================
void sortBest() {
    
    voteCube *toadd;
    voteCube *current;
    int *bestlast;
    int cnt;
    int mm;
    int added;
    
    bestlast=(int *)(malloc(MM*sizeof(int)));
    memset(bestlast,0,MM*sizeof(int));
    
    if (debug5) {
        printf("1");
    }
    dim4=dim3;
    //multi-merge sorting O(MM^2*permodel)
    for (int cnt=0; cnt<=dim4-1; cnt++) {
        if (debug5) {
            printf("2");
        }
        toadd=0;
        for (mm=0; mm<=MM-1; mm++) {
            if (bestlast[mm]==permodel) {
                if (debug5) {
                    printf("3");
                }
                continue;
            }
            if (debug5) {
                printf("4");
            }
            current=*(best+mm*permodel+bestlast[mm]);
            //coping with the sparse voting case (only one voting peak for a given model protein)
            if (!current) {
                if (bestlast[mm]==1) {
                    printf("%d\tAAA\t%s\n",mm+1,mms[mm]);
                    sparse=1;
                }
                dim4-=4-bestlast[mm];
                bestlast[mm]=4;
                continue;
            }
            if (!toadd) {
                toadd=current;
                added=mm;
            } else {
                if (debug5) {
                    printf("5");
                    printf("\n-- %d/%d -- %d[%d] -- %d -- %d --\n",cnt,dim4-1,mm,bestlast[mm],current,toadd);
                }
                if (current->smoothedvote>toadd->smoothedvote) {
                    toadd=current;
                    added=mm;
                }
            }
            if (debug5) {
                printf("6");
            }
        }
        bestsort[cnt]=toadd;
        bestlast[added]++;
        if (debug5) {
            printf("7");
        }
    }
    
}


//=================================================================================================================================================
//=========================================================== :: computeDifferences :: ============================================================
//=================================================================================================================================================
void computeDifferences() {
    
    int mm;
    int i;
    int *done;
    int f;
    voteCube *addThis;
    float bestdiff;
    float diff;
    
    if (!(sparse)) {
        done=(int *)(malloc(MM*sizeof(int)));
        memset(done,0,MM*sizeof(int));
        for (mm=0; mm<=MM-1; mm++) {
            addThis=0;
            bestdiff=-1;
            f=0;
            if (debug4) {
                for (i=0; i<=MM-1; i++) {
                    printf("%d",done[i]);
                }
            }
            printf("Scarti: %d/%d\n",mm+1,MM);
            for (i=0; i<=MM-1; i++) {
                if (M[i]) {
                    diff=(*(best+i*permodel))->smoothedvote-(*(best+i*permodel+1))->smoothedvote;
                } else {
                    diff=0;
                }
                if ((diff>bestdiff)&&(!(done[i]))) {
                    bestdiff=diff;
                    addThis=*(best+i*permodel);
                    f=i;
                }
            }
            diffptrs[mm]=addThis;
            difference[mm]=bestdiff;
            done[f]=1;
        }
    }
}


//=================================================================================================================================================
//============================================================== :: printResults :: ===============================================================
//=================================================================================================================================================
void printResults(int oo) {
    FILE *Fbestlist;
    voteCube *scroll;
    char simulation[80];
    char paramsset[40];
    char filepath[100];
    int par1,par2;
    char par[4];
    char assess[5];
    float ratio;
    double d1,d2;
    
    
    strcpy(simulation,oos);
    strcat(simulation,".");
    if (motifmode) {
        strcpy(paramsset,"motifmode.");
    }
    if (skipself) {
        strcpy(paramsset,"ss.");
    }
    if ((!skipself)&&(!motifmode)) {
        strcpy(paramsset,((R==4)?("I"):((R==3)?"N":(R?((R==1)?"Q":"R"):"L"))));
    } else {
        strcat(paramsset,((R==4)?("I"):((R==3)?"N":(R?((R==1)?"Q":"R"):"L"))));
    }
    strcat(paramsset,".");
    if (adaptivemode) {
        strcat(paramsset,"adaptive.");
        strcat(paramsset,adaptivelabel);
    } else {
        itoa(phimesh,par,10);
        strcat(paramsset,par);
        strcat(paramsset,".");
        d1 = modf((double)(spacemesh),&d2);
        itoa((par2=(int)(d2)),par,10);
        strcat(paramsset,par);
        strcat(paramsset,",");
        itoa((par1=(int)(d1*10)),par,10);
        strcat(paramsset,par);
        if (((int)(d1*100))%10) {
            itoa((par1=((int)(d1*100))%10),par,10);
            strcat(paramsset,par);
        }
    }
    strcat(paramsset,".s");
    itoa(mulsum,par,10);
    strcat(paramsset,par);
    strcat(paramsset,".d");
    itoa(muldist,par,10);
    strcat(paramsset,par);
    if (invmode) {
        strcat(paramsset,".inv");
    } else {
        strcat(paramsset,".dir");
    }                            
    strcat(paramsset,".list");
    strcat(simulation,paramsset);
    
    if (Freport==NULL) {
            strcpy(filepath,".\\reports\\");
            strcat(filepath,"5b.report.");
            strcat(filepath,paramsset);
            if (!motifmode) {
                Freport=fopen(filepath,"w");
            }
            strcpy(filepath,".\\reports\\");
            strcat(filepath,"5b.reportplus.");
            strcat(filepath,paramsset);
            Freportplus=fopen(filepath,"w");
    }
    
    if (sparse) {
        printf("Sparse\n");
        if (!motifmode) {
            fprintf(Freport,"%d\t%s\tVoting space too sparse to make comparison\n",oo,simulation);
        }
        fprintf(Freportplus,"%d\t%s\tVoting space too sparse to make comparison\n",oo,simulation);
    } else {
        strcpy(filepath,".\\results\\");
        strcat(filepath,"5b.best.");
        strcat(filepath,simulation);
        Fbestlist=fopen(filepath,"w");
        for (int cnt=0; cnt<=dim3-1; cnt++) {
            scroll=*(best+cnt);
            if (scroll) {
                fprintf(Fbestlist,"%f\t%f\t%f\t%f\t%f\t%s\t%d\n",scroll->pos.x,scroll->pos.y,scroll->pos.z,
                        scroll->pointvote,scroll->smoothedvote,mms[(scroll->mm)-1]);
            }
            if (cnt%permodel==permodel-1) {
                fprintf(Fbestlist,"\n");
            }
        }
        fclose(Fbestlist);
        strcpy(filepath,".\\results\\");
        strcat(filepath,"5b.best.sort.");
        strcat(filepath,simulation);
        Fbestlist=fopen(filepath,"w");
        for (int cnt=0; cnt<=dim4-1; cnt++) {
            scroll=*(bestsort+cnt);
            if (scroll) {
                fprintf(Fbestlist,"%f\t%f\t%f\t%f\t%f\t%s\t%d\n",scroll->pos.x,scroll->pos.y,scroll->pos.z,
                        scroll->pointvote,scroll->smoothedvote,mms[(scroll->mm)-1]);
            }
            if (cnt%permodel==permodel-1) {
                fprintf(Fbestlist,"\n");
            }
        }
        fclose(Fbestlist);
    
        
        strcpy(filepath,".\\results\\");
        strcat(filepath,"5b.diffptrs.");
        strcat(filepath,simulation);
        Fbestlist=fopen(filepath,"w");
        for (int cnt=0; cnt<=MM-1; cnt++) {
            if (*(diffptrs+cnt)) {                                                                       
                scroll=*(diffptrs+cnt);
                fprintf(Fbestlist,"%f\t%f\t%f\t%f\t%f\t%s\t%d\t%d\n",scroll->pos.x,scroll->pos.y,scroll->pos.z,
                        scroll->smoothedvote,difference[cnt],mms[(scroll->mm)-1],M[scroll->mm-1]);
                if ((scroll->mm)==oo) {
                    if (cnt==0) {
                        ratio=difference[cnt]/difference[cnt+1];
                        if (ratio>1.5) {
                            strcpy(assess,"..");
                        } else {
                            strcpy(assess,"ok");
                        }
                    } else {
                        ratio=difference[cnt]/difference[0];
                        strcpy(assess,"NO");
                    }
                }
                if (cnt%permodel==permodel-1) {
                    fprintf(Fbestlist,"\n");
                }
            }
        }
        fclose(Fbestlist);
        
        if (!motifmode) {
            fprintf(Freport,"%d\t%s\t%s\t%f\t%d\t%s\t%d\n",oo,simulation,assess,ratio,M[oo-1],mms[((*diffptrs)->mm)-1],M[((*diffptrs)->mm)-1]);
        }
        fprintf(Freportplus,"%d\t%s\t%s\t%f\t%d\t%s\t%d\n",oo,simulation,assess,ratio,M[oo-1],mms[((*diffptrs)->mm)-1],M[((*diffptrs)->mm)-1]);
        for (int cnt=0; cnt<=((perobject<MM)?(perobject-1):(MM-1)); cnt++) {
            if (*(diffptrs+cnt)) {
                 fprintf(Freportplus,"\t%d\t%c%d\tmdl %s\t%d\t%f\n",cnt+1,(((*(diffptrs+cnt))->mm==oo)&&(!motifmode))?'*':' ',(*(diffptrs+cnt))->mm,mms[((*(diffptrs+cnt))->mm)-1],M[((*(diffptrs+cnt))->mm)-1],difference[cnt]);
            }
        }
    }
}
